/** Live HUD: session setup → felt/list views, tap logging, blind toggles. */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db/db';
import * as repo from '../db/repo';
import { dealerXY, pendingBadge, seatXY } from '../db/stats';
import { useApp } from '../state/AppContext';
import { useUi } from '../state/UiContext';
import { Icon } from '../components/Icons';
import { Switch, anchorOf, initialsOf } from '../components/Bits';
import { fmt, pct, tagColor, type Player, type Seat } from '../types';

/** Map of playerId -> Player for all seated players (live). */
function useSeatedPlayers(): Map<number, Player> {
  const { live } = useApp();
  const ids = live.seats.filter((s) => s.playerId != null).map((s) => s.playerId!);
  const key = ids.join(',');
  const players = useLiveQuery(
    () => db.players.where('id').anyOf(ids).toArray(),
    [key],
  );
  return useMemo(() => {
    const m = new Map<number, Player>();
    for (const p of players ?? []) m.set(p.id!, p);
    return m;
  }, [players]);
}

export default function HudScreen() {
  const { sessionActive, settings } = useApp();
  const { editMode } = useUi();
  const [view, setView] = useState<'table' | 'list'>(settings.defaultView);
  const [btnMode, setBtnMode] = useState(false);
  const [wide, setWide] = useState(window.innerWidth >= 900);

  useEffect(() => {
    const onResize = () => setWide(window.innerWidth >= 900);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  if (!sessionActive) return <SessionSetup />;

  // Editing always shows the list — drag-to-reorder and remove live there.
  const effectiveView = editMode ? 'list' : view;
  const showCompanion = wide && effectiveView === 'table' && !editMode;
  return (
    <div className="screen">
      {!editMode && (
        <div className="segmented" style={{ marginBottom: 14 }}>
          <button className={view === 'list' ? 'active' : ''} onClick={() => setView('list')}>
            List view
          </button>
          <button className={view === 'table' ? 'active' : ''} onClick={() => setView('table')}>
            Table view
          </button>
        </div>
      )}
      {editMode && (
        <div className="edit-hint">Drag ≡ to reorder · tap − to remove a seat · Done when finished</div>
      )}
      <UndoBar />
      <div className={showCompanion ? 'hud-grid' : ''}>
        <div>
          {effectiveView === 'table' ? (
            <Felt btnMode={btnMode} setBtnMode={setBtnMode} />
          ) : (
            <SeatList editing={editMode} />
          )}
        </div>
        {showCompanion && (
          <div>
            <SeatList />
          </div>
        )}
      </div>
      {!editMode && effectiveView === 'table' && (
        <div className="btn-row" style={{ justifyContent: 'center', marginBottom: 8 }}>
          <button
            className={`btn ${btnMode ? 'primary' : ''}`}
            onClick={() => setBtnMode((v) => !v)}
          >
            {btnMode ? 'Tap a seat to place the button…' : 'Move dealer button'}
          </button>
        </div>
      )}
      <BlindToggles />
    </div>
  );
}

/* ================= session setup ================= */

function SessionSetup() {
  const { startSession } = useApp();
  const { toast } = useUi();
  const venues = useLiveQuery(() => db.venues.toArray(), []) ?? [];
  const [venueChoice, setVenueChoice] = useState('');
  const [newVenue, setNewVenue] = useState('');
  const [stakes, setStakes] = useState('');
  const [tableSize, setTableSize] = useState(9);
  const [heroSeat, setHeroSeat] = useState(5);
  const [btnSeat, setBtnSeat] = useState(1);

  const venueName = venueChoice === '__new__' || venues.length === 0 ? newVenue.trim() : venueChoice;

  const start = async () => {
    if (!venueName) {
      toast('Pick or add a venue first');
      return;
    }
    await startSession(venueName, stakes.trim() || '—', tableSize, Math.min(heroSeat, tableSize), Math.min(btnSeat, tableSize));
  };

  const seatOptions = Array.from({ length: tableSize }, (_, i) => i + 1);

  return (
    <div className="screen">
      <div className="section-title">Start a session</div>
      <div className="card">
        <div className="field">
          <label>Venue</label>
          {venues.length > 0 && (
            <select value={venueChoice} onChange={(e) => setVenueChoice(e.target.value)}>
              <option value="">— choose venue —</option>
              {venues.map((v) => (
                <option key={v.id} value={v.name}>
                  {v.name}
                </option>
              ))}
              <option value="__new__">＋ New venue…</option>
            </select>
          )}
          {(venueChoice === '__new__' || venues.length === 0) && (
            <input
              style={{ marginTop: venues.length ? 8 : 0 }}
              placeholder="e.g. Maryland Live!"
              value={newVenue}
              onChange={(e) => setNewVenue(e.target.value)}
            />
          )}
        </div>
        <div className="field">
          <label>Stakes</label>
          <input
            placeholder="e.g. $1/$3 NL Hold'em"
            value={stakes}
            onChange={(e) => setStakes(e.target.value)}
          />
        </div>
        <div className="field-row">
          <div className="field">
            <label>Table size</label>
            <select value={tableSize} onChange={(e) => setTableSize(parseInt(e.target.value, 10))}>
              {Array.from({ length: 10 }, (_, i) => i + 2).map((n) => (
                <option key={n} value={n}>
                  {n}-max
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Your seat</label>
            <select value={Math.min(heroSeat, tableSize)} onChange={(e) => setHeroSeat(parseInt(e.target.value, 10))}>
              {seatOptions.map((n) => (
                <option key={n} value={n}>
                  Seat {n}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Button at</label>
            <select value={Math.min(btnSeat, tableSize)} onChange={(e) => setBtnSeat(parseInt(e.target.value, 10))}>
              {seatOptions.map((n) => (
                <option key={n} value={n}>
                  Seat {n}
                </option>
              ))}
            </select>
          </div>
        </div>
        <button className="btn primary block" onClick={start}>
          Start session
        </button>
        <div className="field" style={{ marginTop: 10, marginBottom: 0 }}>
          <div className="hint">
            Seats start open — tap ＋ on a seat to add opponents as they settle in. You can
            move the button and change table size any time.
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= felt (table view) ================= */

function Felt({ btnMode, setBtnMode }: { btnMode: boolean; setBtnMode: (v: boolean) => void }) {
  const { live, dispatch, settings } = useApp();
  const { openPlayer, openAssign, toast } = useUi();
  const playersById = useSeatedPlayers();

  // Hero is pinned to the bottom-center. The human dealer is a fixed marker
  // between the highest seat and seat 1 (seat 1 to its screen-left). Where it
  // lands depends only on which seat Hero occupies.
  const n = live.seats.length;
  const heroSeat = live.seats.find((s) => s.hero)?.seatNo ?? 1;
  const posOf = (seatNo: number): [number, number] => seatXY(seatNo, heroSeat, n);
  const [dealerX, dealerY] = dealerXY(heroSeat, n);
  const compactDealer = n >= 10;

  const tapSeat = (s: Seat, e: React.MouseEvent) => {
    if (btnMode) {
      if (s.open) {
        toast('Button must be on an occupied seat');
        return;
      }
      dispatch({ type: 'SET_BTN', seatNo: s.seatNo });
      setBtnMode(false);
      return;
    }
    if (s.open) {
      openAssign(s.seatNo);
      return;
    }
    if (s.hero) {
      toast("That's you — Hero isn't tracked like an opponent");
      return;
    }
    if (s.playerId != null) openPlayer(s.playerId, s.seatNo, anchorOf(e));
  };

  return (
    <div className="felt-wrap">
      <div className="felt" />
      <div
        className={`dealer-gap${compactDealer ? ' compact' : ''}`}
        style={{ left: `${dealerX}%`, top: `${dealerY}%` }}
        title="Dealer (house)"
      >
        <Icon name="cards" />
      </div>
      <div className="felt-center">
        <div className="stakes">{live.stakes}</div>
        <div className="venue">
          {live.venueName} · Hand #{live.handNo}
        </div>
      </div>
      {live.seats.map((s) => {
        const [x, y] = posOf(s.seatNo);
        if (s.open) {
          return (
            <div
              key={s.seatNo}
              className={`seat-chip open ${btnMode ? '' : ''}`}
              style={{ left: `${x}%`, top: `${y}%` }}
              onClick={(e) => tapSeat(s, e)}
            >
              <div className="num">{s.seatNo}</div>
              <div className="initials">＋</div>
              <div className="pos">Open</div>
            </div>
          );
        }
        const p = s.playerId != null ? playersById.get(s.playerId) : undefined;
        const ring = p?.tag ? tagColor(p.tag, settings.tags) : undefined;
        const badge = pendingBadge(live.currentEntries, s.seatNo);
        const hasNote = (p?.notes?.length ?? 0) > 0;
        return (
          <div key={s.seatNo}>
            <div
              className={`seat-chip ${s.hero ? 'hero' : ''} ${btnMode ? 'btn-target' : ''} ${s.sittingOut ? 'sitting-out' : ''}`}
              style={{ left: `${x}%`, top: `${y}%`, ...(ring && !s.hero ? { borderColor: ring } : {}) }}
              onClick={(e) => tapSeat(s, e)}
            >
              <div className="num">{s.seatNo}</div>
              <div className="initials">{s.hero ? 'YOU' : initialsOf(p?.name ?? '?')}</div>
              <div className="pos">{s.pos}</div>
              {badge && <div className="act-tag">{badge}</div>}
              {hasNote && !badge && <div className="note-dot">📝</div>}
              {s.stack && <div className="stack-tag">${s.stack}</div>}
            </div>
            {s.dealer &&
              (() => {
                const dx = x - 50,
                  dy = y - 50;
                const len = Math.hypot(dx, dy) || 1;
                return (
                  <div
                    className="dealer-btn"
                    style={{ left: `${x + (dx / len) * 8}%`, top: `${y + (dy / len) * 8}%` }}
                  >
                    D
                  </div>
                );
              })()}
          </div>
        );
      })}
    </div>
  );
}

/* ================= seat list ================= */

function SeatList({ editing = false }: { editing?: boolean }) {
  const { live, dispatch, settings } = useApp();
  const { openPlayer, openAssign, toast } = useUi();
  const playersById = useSeatedPlayers();
  // Inline quick-note editor: 📝 on a row opens an input right under it —
  // no popup, autofocused, Enter saves, Esc closes.
  const [noteSeat, setNoteSeat] = useState<number | null>(null);
  const [noteDraft, setNoteDraft] = useState('');

  // Drag-to-reorder (pointer events → works on touch and mouse).
  const [dragSeat, setDragSeat] = useState<number | null>(null);
  const [overSeat, setOverSeat] = useState<number | null>(null);
  const rowRefs = useRef<Map<number, HTMLDivElement>>(new Map());
  const setRowRef = (seatNo: number) => (el: HTMLDivElement | null) => {
    if (el) rowRefs.current.set(seatNo, el);
    else rowRefs.current.delete(seatNo);
  };
  const rowClass = (seatNo: number, base: string) =>
    `${base}${dragSeat === seatNo ? ' dragging' : ''}` +
    `${overSeat === seatNo && dragSeat != null && dragSeat !== seatNo ? ' drag-over' : ''}`;
  const onHandleDown = (seatNo: number) => (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setDragSeat(seatNo);
    setOverSeat(seatNo);
  };
  const onHandleMove = (e: React.PointerEvent) => {
    if (dragSeat == null) return;
    let target = dragSeat;
    for (const [sn, el] of rowRefs.current) {
      const r = el.getBoundingClientRect();
      if (e.clientY >= r.top && e.clientY <= r.bottom) {
        target = sn;
        break;
      }
    }
    setOverSeat(target);
  };
  const onHandleUp = (e: React.PointerEvent) => {
    e.stopPropagation();
    if (dragSeat != null && overSeat != null && dragSeat !== overSeat) {
      dispatch({ type: 'MOVE_SEAT', from: dragSeat, to: overSeat });
    }
    setDragSeat(null);
    setOverSeat(null);
  };
  const removeSeat = (seatNo: number, hero: boolean) => {
    if (hero) return toast("That's your seat — move yourself first, then remove it");
    if (live.seats.length <= 2) return toast('Keep at least 2 seats');
    dispatch({ type: 'REMOVE_SEAT', seatNo });
  };
  const RmBtn = ({ seatNo, hero }: { seatNo: number; hero: boolean }) =>
    editing ? (
      <button
        className="rm-seat"
        title="Remove this seat"
        onClick={(e) => {
          e.stopPropagation();
          removeSeat(seatNo, hero);
        }}
      >
        −
      </button>
    ) : null;
  const Handle = ({ seatNo }: { seatNo: number }) =>
    editing ? (
      <div
        className="drag-handle"
        title="Drag to reorder"
        onPointerDown={onHandleDown(seatNo)}
        onPointerMove={onHandleMove}
        onPointerUp={onHandleUp}
        onClick={(e) => e.stopPropagation()}
      >
        ≡
      </div>
    ) : null;

  const saveQuickNote = (playerId: number, name: string) => {
    const text = noteDraft.trim();
    if (!text) {
      setNoteSeat(null);
      return;
    }
    void repo.addPlayerNote(playerId, text);
    toast(`Note saved on ${name}`);
    setNoteDraft('');
    setNoteSeat(null);
  };

  return (
    <div className={editing ? 'seat-list editing' : 'seat-list'}>
      <div className="seat-list-head">
        <div className="stat-quad">
          <div className="sh">VPIP</div>
          <div className="sh">PFR</div>
          <div className="sh">3B</div>
          <div className="sh">Hands</div>
        </div>
      </div>
      {live.seats.map((s) => {
        if (s.open) {
          return (
            <div
              className={rowClass(s.seatNo, 'seat-row open')}
              key={s.seatNo}
              ref={setRowRef(s.seatNo)}
            >
              <RmBtn seatNo={s.seatNo} hero={false} />
              <div className="badge">{s.seatNo}</div>
              <div className="row-main">
                <div className="row-name">Open Seat</div>
              </div>
              <button className="mini-btn enabled" onClick={() => openAssign(s.seatNo)}>
                ＋ Add
              </button>
              <button
                className="mini-btn"
                title="Move yourself to this seat"
                onClick={() => {
                  dispatch({ type: 'MOVE_HERO', seatNo: s.seatNo });
                  toast(`You moved to seat ${s.seatNo}`);
                }}
              >
                Sit here
              </button>
              <Handle seatNo={s.seatNo} />
            </div>
          );
        }
        const p = s.playerId != null ? playersById.get(s.playerId) : undefined;
        const c = p?.counters;
        const ring = p?.tag ? tagColor(p.tag, settings.tags) : undefined;
        const badge = pendingBadge(live.currentEntries, s.seatNo);
        const notePreview = p?.notes?.length ? p.notes[p.notes.length - 1].text : '';
        return (
          <div key={s.seatNo}>
          <div
            className={rowClass(s.seatNo, s.sittingOut ? 'seat-row sitting-out' : 'seat-row')}
            ref={setRowRef(s.seatNo)}
            onClick={(e) => {
              if (s.hero) toast("That's you — Hero isn't tracked like an opponent");
              else if (s.playerId != null) openPlayer(s.playerId, s.seatNo, anchorOf(e));
            }}
          >
            <RmBtn seatNo={s.seatNo} hero={s.hero} />
            <div
              className={`badge ${s.hero ? 'hero' : ''}`}
              style={ring && !s.hero ? { borderColor: ring } : undefined}
              title={s.sittingOut ? 'Tap to sit back in' : 'Tap to sit this player out'}
              onClick={(e) => {
                e.stopPropagation();
                dispatch({ type: 'TOGGLE_SITOUT', seatNo: s.seatNo });
              }}
            >
              {s.seatNo}
            </div>
            <div className="row-main">
              <div className="row-name-line">
                <div className="row-name">
                  {s.hero ? 'Hero' : p?.name ?? '?'}
                  {!s.hero && notePreview
                    ? ` — ${notePreview.slice(0, 18)}${notePreview.length > 18 ? '…' : ''}`
                    : ''}
                </div>
                {s.sittingOut ? (
                  <span className="pos-chip out">OUT</span>
                ) : (
                  s.pos && (
                    <span
                      className={`pos-chip clickable${s.dealer ? ' btn' : ''}`}
                      title="Set this seat as the button"
                      onClick={(e) => {
                        e.stopPropagation();
                        dispatch({ type: 'SET_BTN', seatNo: s.seatNo });
                      }}
                    >
                      {s.pos}
                    </span>
                  )
                )}
                {badge && <span className="pending-chip">{badge}</span>}
                {s.stack && <span className="row-stack">${s.stack}</span>}
              </div>
              <div className="stat-quad">
                <div className="stat-cell">{s.hero ? '–' : fmt(pct(c?.vpip ?? 0, c?.dealt ?? 0))}</div>
                <div className="stat-cell">{s.hero ? '–' : fmt(pct(c?.pfr ?? 0, c?.dealt ?? 0))}</div>
                <div className="stat-cell">{s.hero ? '–' : fmt(pct(c?.threeBet ?? 0, c?.threeBetOpp ?? 0))}</div>
                <div className="stat-cell">{s.hero ? '–' : c?.dealt ?? 0}</div>
              </div>
            </div>
            <div className="row-actions">
              <button
                className={`mini-btn enabled ${badge && badge !== 'Open' && !badge.includes('Bet') ? 'tapped' : ''}`}
                disabled={s.sittingOut}
                onClick={(e) => {
                  e.stopPropagation();
                  dispatch({ type: 'TAP', seatNo: s.seatNo, playerId: s.playerId, action: 'call' });
                }}
              >
                Call
              </button>
              <button
                className={`mini-btn enabled ${badge && (badge === 'Open' || badge.includes('Bet')) ? 'tapped' : ''}`}
                disabled={s.sittingOut}
                onClick={(e) => {
                  e.stopPropagation();
                  dispatch({ type: 'TAP', seatNo: s.seatNo, playerId: s.playerId, action: 'raise' });
                }}
              >
                Raise
              </button>
              {!s.hero && s.playerId != null && (
                <button
                  className={`mini-btn ${noteSeat === s.seatNo ? 'tapped' : ''}`}
                  title="Quick note — types right here, no popup"
                  onClick={(e) => {
                    e.stopPropagation();
                    setNoteDraft('');
                    setNoteSeat(noteSeat === s.seatNo ? null : s.seatNo);
                  }}
                >
                  📝
                </button>
              )}
            </div>
            <Handle seatNo={s.seatNo} />
          </div>
          {noteSeat === s.seatNo && s.playerId != null && (
            <div className="quick-note">
              <input
                autoFocus
                value={noteDraft}
                placeholder={`Note on ${p?.name ?? 'player'}… Enter saves, Esc closes`}
                onChange={(e) => setNoteDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') saveQuickNote(s.playerId!, p?.name ?? 'player');
                  if (e.key === 'Escape') setNoteSeat(null);
                }}
              />
              <button
                className="mini-btn enabled"
                onClick={() => saveQuickNote(s.playerId!, p?.name ?? 'player')}
              >
                Save
              </button>
            </div>
          )}
          </div>
        );
      })}
    </div>
  );
}

/* ================= undo bar + toggles ================= */

function UndoBar() {
  const { live, dispatch } = useApp();
  const last = live.currentEntries[live.currentEntries.length - 1];
  if (!last) return null;
  const label =
    last.action === 'raise'
      ? last.raiseLevel === 1
        ? 'Open raise'
        : `${last.raiseLevel + 1}-bet`
      : last.action;
  return (
    <div className="undo-bar">
      <div>
        This hand: <b>{live.currentEntries.length}</b> action
        {live.currentEntries.length === 1 ? '' : 's'} · last: <b>seat {last.seatNo} {label}</b>
      </div>
      <div className="undo-actions">
        <button className="mini-btn enabled" onClick={() => dispatch({ type: 'UNDO_TAP' })}>
          Undo
        </button>
        <button className="mini-btn" onClick={() => dispatch({ type: 'CLEAR_HAND' })}>
          Clear
        </button>
      </div>
    </div>
  );
}

function BlindToggles() {
  const { live, dispatch } = useApp();
  return (
    <div className="card" style={{ marginTop: 6 }}>
      <div className="toggle-row">
        <div>
          <div className="label">No Small Blind Player</div>
        </div>
        <Switch on={live.noSB} onToggle={() => dispatch({ type: 'TOGGLE', key: 'noSB' })} />
      </div>
      <div className="toggle-row">
        <div>
          <div className="label">Straddle</div>
        </div>
        <Switch on={live.straddle} onToggle={() => dispatch({ type: 'TOGGLE', key: 'straddle' })} />
      </div>
      <div className="toggle-row">
        <div>
          <div className="label">Must Straddle</div>
          <div className="sub">Keeps straddle on between hands</div>
        </div>
        <Switch on={live.mustStraddle} onToggle={() => dispatch({ type: 'TOGGLE', key: 'mustStraddle' })} />
      </div>
    </div>
  );
}
